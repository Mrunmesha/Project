	<nav class="ts-sidebar" style="background: linear-gradient(to right, rgb(195, 20, 50), rgb(36 11 54 / 30%));">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label" style="color:black">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard" style="color:black"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o" style="color:black"></i> Brands</a>
<ul>
<li><a href="create-brand.php">Create Brand</a></li>
<li><a href="manage-brands.php">Manage Brands</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-car" style="color:black"></i> Vehicles</a>
					<ul>
						<li><a href="post-avehical.php">Post a Vehicle</a></li>
						<li><a href="manage-vehicles.php">Manage Vehicles</a></li>
					</ul>
				</li>

<li><a href="#"><i class="fa fa-sitemap" style="color:black"></i> Bookings</a>
					<ul>
						<li><a href="new-bookings.php">New</a></li>
						<li><a href="confirmed-bookings.php">Confirmed</a></li>
						<li><a href="canceled-bookings.php">Canceled</a></li>
					</ul>
				</li>

		

				<li><a href="testimonials.php"><i class="fa fa-table" style="color:black"></i> Manage Testimonials</a></li>
				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop" style="color:black"></i> Manage Conatct Us Query</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users" style="color:black"></i> Registered Users</a></li>
			<!-- <li><a href="manage-pages.php"><i class="fa fa-files-o" ></i> Manage Pages</a></li> -->
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o" style="color:black"></i> Update Contact Information</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table" style="color:black"></i> Manage Subscribers</a></li>

			</ul>
		</nav>