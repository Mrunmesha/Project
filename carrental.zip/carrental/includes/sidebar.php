<div class="profile_nav">
          <ul>
            <li><a href="profile.php" style="color:#e35f21">Profile Settings</a></li>
              <li><a href="update-password.php" style="color:#e35f21">Update Password</a></li>
            <li><a href="my-booking.php" style="color:#e35f21">My Booking</a></li>
            <li><a href="post-testimonial.php" style="color:#e35f21">Post a Testimonial</a></li>
               <li><a href="my-testimonials.php" style="color:#e35f21">My Testimonials</a></li>
            <li><a href="logout.php" style="color:#e35f21">Sign Out</a></li>
          </ul>
        </div>
      </div>